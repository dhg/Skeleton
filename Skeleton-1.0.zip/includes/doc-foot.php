		
		<!-- JS
		================================================== -->
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.js"></script>
		<script>window.jQuery || document.write("<script src='javascripts/jquery-1.5.1.min.js'>\x3C/script>")</script>
		<script src="javascripts/modernizr-1.7.min.js"></script>
		<script src="javascripts/app.js"></script>
	</body>
</html>